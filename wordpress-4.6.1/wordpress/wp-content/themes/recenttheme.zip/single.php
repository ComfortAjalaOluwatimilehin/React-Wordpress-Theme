<!DOCTYPE html>
	<html lang="eng" xmlns="http://www.w3.org/1999/xhtml">
	<head><title><?php the_title();?></title><?php wp_head();?></head>
	<body>
			
						<?php
							
					if(have_posts()):
								while(have_posts()):
								
									the_post();
						?>
										<div  id="singleposttheme" >
												<div id="single_title"><p><?php the_title();?></p></div>
												<div id="single_date"><p><?php the_time('F jS, Y')?></p></div>
											
												<div id="single_thumbnail" style="background-image:url(<?php the_post_thumbnail_url();?>)"></div>
												<div id="single_contents"><?php the_content();?></div>
											<div id="single_buttons">
												<div id="single_up_down" class="thumbnail"><?php echo next_post_link("%link","<span class='glyphicon glyphicon-menu-up'></span>"); ?></div>
												<div id="single_back" class="thumbnail"><?php echo previous_post_link("%link","<span class='glyphicon glyphicon-menu-down'></span>"); ?></div>
											</div>
											<div id="single_go_back"><a href="<?php echo get_bloginfo("wpurl") ?>"><span class="glyphicon glyphicon-equalizer"></span></a></div>
										</div>
						<?php			
								endwhile;
							endif;

					?>
					
				
	</body>

	</html>