<?php

function Comfort_resources(){
	wp_enqueue_style("style",get_stylesheet_uri());
};
add_theme_support( 'post-thumbnails' ); 
add_action("wp_enqueue_scripts","Comfort_resources");

//Navigation Menu
register_nav_menus(array(
	"top" =>__("Top Menu"),
	"bottom"=> __("Bottom Menu")
));
?>