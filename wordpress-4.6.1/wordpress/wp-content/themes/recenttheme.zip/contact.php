<?php


/************
Template Name: Contact Template
*****/

?>

<html lang="eng" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>Contact</title>
			<?php wp_head();?>
			<link rel="stylesheet" href="/wordpress/wp-content/themes/learningwordpress/style2.css"/>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"  type="text/javascript"></script>
	</head>
	<body id="contacbody">
		<div id="javascript_projects_navigation">
				<span class="glyphicon glyphicon-align-justify"></span>
				
			</div>
			<div id="slider_projects">
					<?php $argsTop = array("theme_location"=>"top"); wp_nav_menu($argsTop);?>
				</div>
		<div class="socials" style="background:#966b9d"><a href="https://twitter.com/Com4fort"><i class="fa fa-twitter fa-2x" aria-hidden="true"></i></a></div>
		<div class="socials" style="background:#f2b880"><a href="https://de.linkedin.com/in/comfort-ajala-40838b101" ><i class="fa fa-linkedin fa-2x" aria-hidden="true"></i></a></div>
		<div class="socials" style="background:#f9627d"><a href="https://www.youtube.com/channel/UCXXWOMMXCX0dXAy94ITzxxg"><i class="fa fa-youtube fa-2x" aria-hidden="true"></i></a></div>
		<div class="socials" style="background:#ffe5d9"><a href="https://github.com/ajalacomfort"><i class="fa fa-github-alt fa-2x" aria-hidden="true"></i></a></div>
		<div class="socials" style="background:#e7cfbc"><a href="mailto:ajalacomfort16@yahoo.com?Subject=Hello%20again" target="_top"><i class="fa fa-envelope fa-2x" aria-hidden="true"></i></a></div>
		<div class="socials"  style="background:#119da4"><a href="http://codepen.io/AJALACOMFORT/#"><i class="fa fa-codepen fa-2x" aria-hidden="true"></i></a></div>
	
	
	<script type="text/javascript">
		
				$(".glyphicon-align-justify").click(function(){
			$("#slider_projects").animate({width:'toggle'},550);
	})
	$("#slider_projects").click(function(){
			$("#slider_projects").animate({width:'toggle'},350);
	})
	</script>
	</body>
	</html>