<?php 
/***********

Template Name: About Template

*****/
?>
<!DOCTYPE html>
	<html lang="eng" xmlns="http://www.w3.org/1999/xhtml">
	<head><title>About</title><?php wp_head();?></head>
	<body>
	
		<div class="page_navigation">
			<?php 
				$argsTop = array("theme_location"=>"top");
				wp_nav_menu($argsTop);
			?>
											
		</div>
		<div class="page_content">
			<div>
				You can call me <span class="semi_highlight">Comfort or Oluwatimilehin</span>, whichever makes you think less.
				I love coding in <span class="semi_highlight">JavaScript</span> and building themes in <span class="highlight">Wordpress</span> but I am a graduate 
				in the Biochemistry Field, wierd right? <br/>
				I really enjoy learning languages, both foreign and programming, especially if 
				they help me achieve a goal. I am definitely a great listener, experience has taught me that.
				<br/>
				I am nigerian, lived in Russia (but do not speak Russian), 
				graduated and study in Germany, yes I speak <span class="highlight">German</span>. And I am currently 
				learning <span class="semi_highlight">Korean</span>. 
				<br/>
				I am now open to <span class="highlight">Internships</span>, <span class="semi_highlight">Full Employment</span> ( Remote) in Wordpress development or JavaScript 
				Interactive Design.
				<br/>
				Please do message me on my <a href="https://de.linkedin.com/in/comfort-ajala-40838b101" target="_blank">LinkedIn platform</a> or 
				my via <a href="https://twitter.com/Com4fort" target="_blank">Twitter</a>
				See ya! <br/>
				<span class="highlight">Yes I built this Theme</span>
			</div>
		</div>
	
	</body>
	</html>