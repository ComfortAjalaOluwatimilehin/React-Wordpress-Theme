<?php
/******Template Name:Category Page***/ 
?>

<html>
	<head>
		<title></title>
			<?php wp_head();?>
			<link rel="stylesheet" href="/wordpress/wp-content/themes/learningwordpress/style2.css"/>
	</head>
	<body>
			
			<div id="category">
				<?php
					$id = get_query_var( 'cat' );
					$posts = get_posts(-1, $id);
				?>
				<?php foreach ( $posts as $post ) : setup_postdata( $post ); ?>
					<li class="category_list">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</li>
				<?php endforeach; ?>
					
	
	
	
	
	
			</div>
	</body>
	
</html>;