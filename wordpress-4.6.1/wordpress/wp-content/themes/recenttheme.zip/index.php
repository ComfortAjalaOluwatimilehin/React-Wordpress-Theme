<?php
		get_header();
?>
<div id="show_nav" class="thumbnail"><span class="glyphicon glyphicon-align-right"></span></div>
<div id="mainbody">
	<div id="content">
	<?php
	
	if(have_posts()):
				while(have_posts()):
					the_post();
		?>
		
				<div class="post" style="background-image:url(<?php the_post_thumbnail_url();?>)">
						
								<div class="shadow">
									<div class="tags">
										<?php the_category();?>
									</div>
									<div class="title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</div>
									<div class="date">
										<?php the_time("F jS, Y"); ?>
									</div>
									<div class="author">
										<?php the_author(); ?>
									</div>
								</div>
						
				</div>	
				
		<?php			
				endwhile;
			endif;

	?>
	

	</div>
	<?php
		/**get_sidebar();* NOT YET*/
	?>
<?php
		get_footer();
?>



