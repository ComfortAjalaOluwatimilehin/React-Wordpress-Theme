<?php


/************
Template Name: Project Template
*****/

?>

<html lang="eng" xmlns="http://www.w3.org/1999/xhtml">
	<head>
			<title>Projects</title>
			<?php wp_head();?>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"  type="text/javascript"></script>
			<script src="https://unpkg.com/babel-core@5.8.38/browser.min.js" type="text/javascript"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.3.1/react.min.js" type="text/javascript"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/react/15.3.1/react-dom.min.js" type="text/javascript"></script>
		
			<link rel="stylesheet" href="/wordpress/wp-content/themes/learningwordpress/style2.css"/>
	</head>
	<body >
			<div id="javascript_projects_navigation">
				<span class="glyphicon glyphicon-align-justify"></span>
				
			</div>
			<div id="slider_projects">
					<?php $argsTop = array("theme_location"=>"top"); wp_nav_menu($argsTop);?>
				</div>
			<div id="space"></div>
			
			
			<script type="text/javascript">
			
				
					$(document).ready(function(){
								//watch navigation 
								$("#show_nav").click(function(){$("#header_section").slideToggle();})
					})
			
			
					$(document).ready(function(){
						//click on icon
						
						$(".glyphicon-align-justify").click(function(){
								$("#slider_projects").animate({width:'toggle'},550);
						})
						$("#slider_projects").click(function(){
								$("#slider_projects").animate({width:'toggle'},350);
						})
					})

</script>

<script type="text/babel">

/**************************************************************REACT*************************************/
var projects= [
  
  {
    title:"Dynamic Calender",
    link:"http://codepen.io/AJALACOMFORT/full/VjGPgw/",
	image:"calender.png",
	description:"The dynamic calender is currently one of my favorite javascript projects  that really motivated me to push more in the field. it took weeks, yes weeks for me to really understand the concept of programming/coding and to achieve this. The interface was not the problem, rather the logic behind it. There are actually two  versions of the calender in my codepen; the first being this one, the second being an updated version where the days of both the previous and upcoming months are displayed.  This was fun."
  },
  {
    title:"Color Picker",
    link:"http://codepen.io/AJALACOMFORT/full/jrAGON/",
	image:"colorpicker.png",
	description:"Color Picker has a simple but user friendly interface. I really learned alot about the maths behind the colors. I furthered my knowledge of Objects and Constructor doing this project. Yep, ,worth it"
  },
  {
    title:"Calculator",
    link:"http://codepen.io/AJALACOMFORT/full/EydBAR/",
	image:"calculator.png",
	description:"A simple calculator with a complex background. I can honestly say that the logic could have been done better. Know that I know of Constructors and Stack data structure. I hope to create a better and clean code base for this project. "
  },
  {
    title:"Material Chat Interface",
    link:"http://codepen.io/AJALACOMFORT/full/xOyWpz/",
	image:"chat.png",
	description:"Nothing really out of the ordinary; just decided to replicate the interface of a chat app I saw under google images. Yep, boredom!"	
  },
  {
    title:"Attempt at Game of Life",
    link:"http://codepen.io/AJALACOMFORT/full/ZOGxxm/",
	image:"life.png",
	description:"I learned most of my JS via the Free Code Camp website and there one had to complete the \"Game of Life\" challenge with React.js. After countless tries, I still did no succeed in replicating the game. However in the midst of dirt, there can be diamonds, or rocks, or just dirt. I will just accept it as it is or re-do it later in the nearest 5 life times. Yes I hated this project."
  },
  {
    title:"Tic Tac Toe",
    link:"http://codepen.io/AJALACOMFORT/full/YqRGqL/",
	image:"tictac.png",
	description:"I so loved this challenge! This was the project that made me fall hard for JavaScript. Yes I was playing hard to get, but I fell hard. "
  }
  
]

/********************************************************************JSON*********************************/


var ProjectDisplay = React.createClass({
		
		getInitialState(){return {pointer:0,up:false,down:true}},
		update(direction){this.direction(direction);},
		direction(direction){
			console.log(this.state.pointer,projects.length);
			if(this.state.pointer == 0){this.setState({up:false})}
			else if(this.state.pointer == (projects.length - 1)){this.setState({down:false})}
			else{this.setState({up:true,down:true})}
			return this.check(direction);
		},
		check(direction){
			console.log("CHECKING")
			if(direction == "up" && this.state.up == true){this.setState({pointer:this.state.pointer - 1})}
			else if(direction == "down" && this.state.down == true){this.setState({pointer:this.state.pointer + 1});console.log(this.state.down);}
			return;
		},
		render(){
				var obj = projects[this.state.pointer];
				var divstyle={backgroundImage: 'url(' + "/wordpress/images/" + obj.image + ')'}
				
					return(
							<div>
								<div id="pointer_changing">
								<span className="glyphicon glyphicon-chevron-up " onClick={this.update.bind(null,"up")}></span>
									 <span className="glyphicon glyphicon-chevron-down " onClick={this.update.bind(null,"down")}></span> 
								</div>
								<div id="image_spot">
									<div style={divstyle}></div>
								</div>
								<div id="info_spot">
										<p>{obj.title}</p>
											<span><a href={obj.link} target="_blank">See more </a></span>
								</div>
								<div id="description_spot">
									<blockquote>
									{obj.description}
									</blockquote>
								</div>
							</div>
					
					)
		}
	
})











/****************************************************************************************************RENDER***********************************/

ReactDOM.render(<ProjectDisplay/>,document.getElementById("space"))
			
			</script>
	</body>
</html>