<!DOCTYPE html>
<html lang="eng" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Comfort's Blog</title><?php wp_head();?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"  type="text/javascript"></script>
</head>
<body>
	<div id="header_section" >
					<div id="searchbox"></div>
					<div id="header_top_section">
								<nav class="fifty_percent">
									
										<?php 
											$argsTop = array("theme_location"=>"top");
											wp_nav_menu($argsTop);?>
											
									
								</nav>
					</div>
					<div id="header_bottom_section">
					
								<nav>
									
										<?php 
											$argsBottom = array("theme_location"=>"bottom");
											wp_nav_menu($argsBottom);
										?>
									
								</nav>
					</div>
			
	
	
	</div>
	<script type="text/javascript">
			
				
					$(document).ready(function(){
								//watch navigation 
								$("#show_nav").click(function(){$("#header_section").slideToggle();})
					})
			
			
					$(document).ready(function(){
						//click on icon
						
						$(".glyphicon-align-justify").click(function(){
								$("#slider_projects").animate({width:'toggle'},550);
						})
						$("#slider_projects").click(function(){
								$("#slider_projects").animate({width:'toggle'},350);
						})
					})

</script>

	
	